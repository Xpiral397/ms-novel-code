use clap::Parser;
use serde::Deserialize;
use std::{
    collections::HashMap,
    fs,
    io::{self, ErrorKind},
    path::{Path, PathBuf},
    process::{Command, ExitStatus},
    time::{Duration, Instant},
};
use wait_timeout::ChildExt;

/// ANSI color codes
mod colors {
    pub const RESET: &str = "\x1B[0m";
    pub const RED: &str   = "\x1B[91m";
    pub const GREEN: &str = "\x1B[92m";
    pub const BLUE: &str  = "\x1B[94m";
    pub const BOLD: &str  = "\x1B[1m";
}
use colors::*;

#[derive(Parser)]
#[command(about = "Validate & run a Rust‑task notebook")]
struct Args {
    /// e.g. `colab/001.ipynb`
    #[arg(value_hint = clap::ValueHint::FilePath)]
    task_file: PathBuf,

    /// How many times to run tests
    #[arg(short, long, default_value_t = 1)]
    runs: usize,

    /// Timeout per run in seconds
    #[arg(short, long, default_value_t = 120)]
    timeout: u64,
}

#[derive(Deserialize)]
#[serde(tag = "cell_type", rename_all = "lowercase")]
enum Cell {
    Markdown { source: Vec<String> },
    Code     { source: Vec<String> },
}

#[derive(Deserialize)]
struct Notebook { cells: Vec<Cell> }

fn load_notebook(path: &Path) -> io::Result<Notebook> {
    if !path.exists() {
        return Err(io::Error::new(ErrorKind::NotFound, "Notebook file not found"));
    }
    if path.extension().and_then(|s| s.to_str()) != Some("ipynb") {
        return Err(io::Error::new(ErrorKind::InvalidInput, "Expected a .ipynb file"));
    }
    let raw = fs::read_to_string(path)?;
    serde_json::from_str(&raw)
        .map_err(|e| io::Error::new(ErrorKind::Other, format!("JSON error: {}", e)))
}

/// Grab the lines between the first ```rust and the next ```
fn extract_rust_block(lines: &[String]) -> String {
    let mut in_block = false;
    let mut out = Vec::new();
    for line in lines {
        let t = line.trim_start();
        if t.starts_with("```rust") {
            in_block = true;
            continue;
        }
        if in_block && t.starts_with("```") {
            break;
        }
        if in_block {
            out.push(line.clone());
        }
    }
    out.join("\n")
}

/// Create or recreate `tasks/<stem>` and dump lib/main/test there
fn prepare_workspace(nb: &Notebook, workspace: &Path) -> Result<(), String> {
    if workspace.exists() {
        fs::remove_dir_all(workspace).map_err(|e| e.to_string())?;
    }
    fs::create_dir_all(workspace).map_err(|e| e.to_string())?;

    // Minimal Cargo.toml
    fs::write(
        workspace.join("Cargo.toml"),
        r#"[package]
name = "task_ws"
version = "0.1.0"
edition = "2021"
[dependencies]
"#,
    )
    .map_err(|e| e.to_string())?;

    let mut seen = HashMap::new();

    for cell in &nb.cells {
        let src = match cell {
            Cell::Markdown { source } | Cell::Code { source } => source,
        };
        let joined = src.join("");
        if joined.contains("# lib") && joined.contains("```rust") {
            let dir = workspace.join("src");
            fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
            fs::write(dir.join("lib.rs"), extract_rust_block(src))
                .map_err(|e| e.to_string())?;
            seen.insert("lib", true);
        }
        if joined.contains("# main") && joined.contains("```rust") {
            let dir = workspace.join("src");
            fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
            fs::write(dir.join("main.rs"), extract_rust_block(src))
                .map_err(|e| e.to_string())?;
            seen.insert("main", true);
        }
        if joined.contains("# test") && joined.contains("```rust") {
            let dir = workspace.join("tests");
            fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
            fs::write(dir.join("integration.rs"), extract_rust_block(src))
                .map_err(|e| e.to_string())?;
            seen.insert("test", true);
        }
    }

    for &req in &["lib", "main", "test"] {
        if !seen.contains_key(req) {
            return Err(format!("Missing required code section: `# {}`", req));
        }
    }
    Ok(())
}

fn run_cargo_test(workspace: &Path, timeout: u64) -> Result<ExitStatus, String> {
    let mut child = Command::new("cargo")
        .arg("test")
        .current_dir(workspace)
        .spawn()
        .map_err(|e| e.to_string())?;
    match child.wait_timeout(Duration::from_secs(timeout))
               .map_err(|e| e.to_string())? {
        Some(status) => Ok(status),
        None => {
            let _ = child.kill();
            Err("Timeout reached".into())
        }
    }
}

fn main() {
    let args = Args::parse();

    // derive the folder name under `tasks/` from the notebook stem
    let stem = args
        .task_file
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("task_ws");
    let workspace = Path::new("tasks").join(stem);

    // 1) Load
    let nb = load_notebook(&args.task_file).unwrap_or_else(|e| {
        eprintln!("{}Error loading {}: {}{}", RED, args.task_file.display(), e, RESET);
        std::process::exit(1);
    });

    // 2) Extract & validate
    if let Err(err) = prepare_workspace(&nb, &workspace) {
        eprintln!("{}Validation error:{} {}", RED, BOLD, RESET);
        eprintln!("  {}", err);
        std::process::exit(1);
    }

    // 3) Run tests
    let mut failures = Vec::new();
    for i in 1..=args.runs {
        println!("{}Run {}/{}{}", BLUE, i, args.runs, RESET);
        let start = Instant::now();
        match run_cargo_test(&workspace, args.timeout) {
            Ok(s) if s.success() => {
                println!("{}PASS{} ({:.2}s)", GREEN, RESET, start.elapsed().as_secs_f32());
            }
            Ok(s) => {
                let msg = format!(
                    "Run {}/{} failed (exit code {:?}) in {:.2}s",
                    i, args.runs, s.code(), start.elapsed().as_secs_f32()
                );
                println!("{}FAIL{} {}", RED, RESET, msg);
                failures.push(msg);
            }
            Err(e) => {
                let msg = format!(
                    "Run {}/{} error: {} after {:.2}s",
                    i, args.runs, e, start.elapsed().as_secs_f32()
                );
                println!("{}ERROR{} {}", RED, RESET, msg);
                failures.push(msg);
            }
        }
    }

    // 4) Summary
    if failures.is_empty() {
        println!("{}All tests passed!{}", GREEN, RESET);
        std::process::exit(0);
    } else {
        println!("{}Some runs failed or timed out:{}{}", RED, BOLD, RESET);
        for f in failures {
            println!("  - {}", f);
        }
        std::process::exit(1);
    }
}
