use task_ws::add;



fn main() {

    let sum = add(2, 3);

    println!("2 + 3 = {}", sum);

}




