use task_ws::add;



#[test]

fn test_add_positive() {

    assert_eq!(add(1, 2), 3);

}


